/*
 * MagicButtonAnimation.h
 *
 *  Created on: May 23, 2017
 *      Author: andri
 */

#ifndef COMPONENTS_MAGICBUTTON_SRC_MAGICBUTTONANIMATION_H_
#define COMPONENTS_MAGICBUTTON_SRC_MAGICBUTTONANIMATION_H_

#include "WS2812.h"
#include "WS2812Animator.h"
#include "esp_log.h"

#define DEBUG_MBANIM 	1

#if DEBUG_MBANIM
#define MBANIM_DEBUG_PRINT(...)   	ESP_LOGI("MB_ANIM", __VA_ARGS__); //ESP_LOGD("GESTMGR", __VA_ARGS__);
#else
#define MBANIM_DEBUG_PRINT(...)
#endif

class MagicButtonAnimation {
public:
	MagicButtonAnimation(WS2812 &ws8212);
	virtual ~MagicButtonAnimation();

	void start();
	void stop();
	void run();
	void onAnimationCompleted(WS2812Animator::AnimationFinishedCallback cb) {
		animCompletedCb_ = cb;
	}

protected:
	WS2812 &ws2812_;
	WS2812Animator *animator_ = NULL;

	WS2812Animator::AnimationFinishedCallback animCompletedCb_ = NULL;
	boolean animationPrevStarted_ = false;
};

class MagicButtonFadeInOutAnimation: public MagicButtonAnimation {
public:
	MagicButtonFadeInOutAnimation(WS2812 &ws2812, WS2812Color_t &color);

	void start(uint16_t duration = 0, uint16_t updateInterval = 10);
	void stop();

protected:
	WS2812Color_t& fadingColor_;
};

enum MagicButtonArrow_t {
	ARROW_LEFT = 1,
	ARROW_RIGHT,
	ARROW_UP,
	ARROW_DOWN
};

class MagicButtonArrowAnimation: public MagicButtonAnimation {
public:
	MagicButtonArrowAnimation(WS2812 &ws2812, WS2812Color_t &color);
	void animateArrow(MagicButtonArrow_t arrow);
protected:
	WS2812Color_t& fadingColor_;
};

class MagicButtonFadingAnimation: public MagicButtonAnimation {
public:
	MagicButtonFadingAnimation(WS2812 &ws2812, WS2812Color_t &color);

	void start(uint8_t from = 0, uint8_t to = 100, uint16_t duration = 2000);

protected:
	WS2812Color_t& fadingColor_;
};

#endif /* COMPONENTS_MAGICBUTTON_SRC_MAGICBUTTONANIMATION_H_ */
